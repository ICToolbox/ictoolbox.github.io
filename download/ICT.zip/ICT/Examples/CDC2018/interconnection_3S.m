%% Example in Scialanga, Ampountolas - 
%% Robust Constrained Interpolating Control of Interconnected Systems
%% CDC 2018

% System matrices:              A \in R^{6x6},
%                               B \in R^{12x6},
% State constraints:            -6 <= x <= 6;
% Control constraints:          -0.4 <= u <= 0.4.

warning off
clear all
close all
clc

% number subsystems
no_subs = 3;
% state components
n = zeros(1, no_subs);
% control components
m = zeros(1, no_subs);
for i = 1:no_subs
    n(i) = 2;
    m(i) = 1;
end

fprintf('\n - COMPUTING DECENTRALISED CONTROL FOR A SYSTEM DECOMPOSED IN %d SUBSYSTEMS WITH INTERCONNECTIONS - \n',no_subs);

% number of realisations
r = 2;
Ac = cell(r,1);

% interconnections
a = 0.015;

Ac{1} =  [1.1   1.0    a   0.0   a    0.0 ;  % row1
       0.0   1.0   0.0   a   0.0    a  ;  % row2
       a     0.0   1.1  1.0   a    0.0 ;  % row3
       0.0    a    0.0  1.0  0.0    a  ;  % row4
       a     0.0    a   0.0  1.1   1.0 ;  % row5
       0.0    a    0.0   a   0.0   1.0 ;  % row6
       ];

Bc{1} = [0.0  0.0   0.0 ;
      1.0   0.0   0.0 ;
      0.0   0.0   0.0 ;
      0.0   1.0   0.0 ;
      0.0   0.0   0.0 ;
      0.0   0.0   1.0 ;
      ];

nx = size(Ac{1},1); % state dimension
nu = size(Bc{1},2); % input dimension  

% interconnections
a = 0.01;


% State and control matrices
Ac{2} =  [0.6   1.0    a   0.0   a    0.0 ;  % row1
       0.0   1.0   0.0   a   0.0    a  ;  % row2
       a     0.0   0.6  1.0   a    0.0 ;  % row3
       0.0    a    0.0  1.0  0.0    a  ;  % row4
       a     0.0    a   0.0  0.6   1.0 ;  % row5
       0.0    a    0.0   a   0.0   1.0 ;  % row6
       ];

Bc{2} = Bc{1}; 

% LOCAL state and control constraints
Xmax = 10 * ones(no_subs,1); Umax = 2 * ones(no_subs,1);
Fx = cell(no_subs,1);
Fu = cell(no_subs,1);
gx = cell(no_subs,1);
gu = cell(no_subs,1);
X = cell(no_subs,1);
U = cell(no_subs,1);


for i = 1 : no_subs
    Fx{i} = [eye(n(i)); - eye(n(i))];
    Fu{i} = [eye(m(i)); - eye(m(i))];
    gx{i} = Xmax(i) * ones(2*n(i),1);
    gu{i} = Umax(i) * ones(2*m(i),1);
    X{i} = [Fx{i} gx{i}];
    U{i} = [Fu{i} gu{i}];
end

% objective matrices
Q = eye(nx);      
R = 0.00001 * eye(nu);     

A = cell(no_subs,r);
B = cell(no_subs,r);
D = cell(no_subs,r);
[A, B, D] = cen2dec(Ac,Bc, n, m); 

nsteps = 15;
 x0 = [5.6543 -3 .340 -3.7635 -7 3.2736]';
 
% alpha realisations
rng(1);
alphas = rand(nsteps,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% centralised IC
fprintf('\n\n>>>centralised IC<<<\n\n');


% State constraints
Fxc = blkdiag(Fx{:});
gxc = cat(1, gx{:});
Xc = [Fxc gxc];

 
% %Input constraints
Fuc = blkdiag(Fu{:});
guc = cat(1, gu{:});
Uc = [Fuc guc];

% LQR
KC = dlqr(Ac{1},Bc{1},Q,R);

%% COMPUTATION INVARIANT SETS
% Compute the maximal positively invariant set
fprintf('\n Computing the inner maximal invariant set...');
tmax = 100;
[OmegaC,tstar1,fd] = oinfsetcl(Ac,Bc,[],Xc,Uc,[],-KC,tmax);
F_OmegaC = OmegaC(:, 1:end-1);
g_OmegaC = OmegaC(:,end);
PC = Polyhedron(F_OmegaC(:,1:3),g_OmegaC);

display ('DONE.')


% Compute the maximal robust control invariant set
fprintf('\n Computing the outer maximal robust control invariant set...');
tmax = 2; 
[PhiC,tstar2,fd] = kinfset(Ac,Bc,[],Xc,Uc,[],Xc,tmax);
F_PhiC = PhiC(:,1:end-1);
g_PhiC = PhiC(:,end);
P1C = Polyhedron(F_PhiC(:,1:3),g_PhiC);
display ('DONE.')

% plot invariant sets
figure
plot(PC, 'color', 'red')
hold on
plot(P1C, 'color','yellow', 'alpha', 0.2)
plot3(x0(1), x0(2), x0(3),'*','MarkerSize',10,'LineWidth',2)
hold off
xlabel('x_1')
ylabel('x_2')
zlabel('x_3')
savefig('cS.fig')


display('Computing the centralised interpolating control...');
 
% cX    - computed states in N - steps ;
% cU - implemented IC for N - steps ;
% cS    - computed interpolating coefficient in N - step.

[cX, cU, cS] = cIC(Ac, Bc, -KC, Xc, Uc, OmegaC, PhiC, [], nsteps, x0, alphas);
display('DONE.')



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%% decentralised IC
fprintf('\n\n>>>decentralised IC<<<\n');

W = couplingconstraints(Fx, gx);
Omega = cell(1, no_subs);
Phi = cell(1, no_subs);

Q = cell(1, no_subs);
R = cell(1, no_subs);
K = cell(1, no_subs);

for i = 1: no_subs
   fprintf('\n\n COMPUTATIONS FOR %d -TH SUBSYSTEM...\n',i');   
   
   % Weighting matrices
   Q{i} = eye(n(i));
   R{i} = 0.00001 * eye(m(i));
   K{i} = -dlqr(A{i,1},B{i,1},Q{i},R{i});

   %% COMPUTATION INVARIANT SETS
   % Compute the maximal positively invariant set
   fprintf('\n Computing the inner maximal invariant set...');
   [Omega{i},tstar,fd] = oinfsetcl({A{i,:}},{B{i,:}},{D{i,:}},X{i},U{i},W{i},K{i},30);   
   F_Omega{i} = Omega{i}(:,1:end-1);
   g_Omega{i} = Omega{i}(:,end);
   Omega{i} = [F_Omega{i} g_Omega{i}];
   
   P{i} = Polyhedron(F_Omega{i},g_Omega{i});
   display ('DONE.')
   
   % Compute the maximal robust controlled invariant set
   fprintf('\n Computing the outer maximal robust control invariant set...');
   tmax = 20;
   [Phi{i},tstar,fd] = kinfset({A{i,:}},{B{i,:}},{D{i,:}},X{i},U{i},W{i},X{i},tmax);%max. robust control inv. set
   F_Phi{i} = Phi{i}(:,1:end-1);
   g_Phi{i} = Phi{i}(:,end);
   Phi{i} = [F_Phi{i} g_Phi{i}];
   P1{i} = Polyhedron (F_Phi{i}, g_Phi{i}(:,end));
   display ('DONE.')
  
   
   label_x = ['x_' num2str(sum(n(1:i)) -1)];
   label_y = ['x_' num2str(sum(n(1:i)))];
   figure
   plot(P{i}, 'color', 'red')
   hold on
   plot(P1{i}, 'color','yellow', 'alpha', 0.2)
   plot(x0(sum(n(1:i))-1), x0(sum(n(1:i))),'*')
   hold off
   str = sprintf('Invariant sets S%d',i);
   title (str, 'FontSize', 14, 'FontWeight', 'bold')
   xlabel(label_x)
   ylabel(label_y)
end

% allocate history matrices
dX = zeros(nx,nsteps+1); % state
dU = zeros(nu,nsteps); % input
dS = zeros(no_subs,nsteps);

[dX, dU, dS] = dIC(A, B, D, K, X, U, W, Omega, Phi, nsteps, x0, alphas);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PLOTs: STATE, CONTROL AND INTERPOLATING COEFFICIENT EVOLUTION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tvec = 0:nsteps;
plus_x = 0.2;
plus_u = 0.05;


figure
stairs(alphas, 'b')
xlabel('Time')
ylabel('\alpha')
title('\alpha realisation')

figure
stairs(cS,'b')
hold on;
stairs(dS(1,:), 'r-x')
stairs(dS(2,:), 'g-o')
stairs(dS(3,:), 'k-*')
xlabel('Time')
ylabel('s')
ymax = max(max(dS));
axis([1 nsteps -.1 ymax+0.1]);
grid on;
legend('s for cIC', 's_1', 's_2', 's_3')

% plot states
for i = 1:no_subs
   for j = 1 : n(i)   
    y_Label = ['x_{' num2str(i) ','  num2str(j) '}'];
    figure
    hold on;
    stairs(tvec,cX(sum(n(1:i-1)) + j,:), 'm--'); 
    stairs(tvec,dX(sum(n(1:i-1)) + j,:), 'b'); 
    axis([0,nsteps,-(10+plus_x),10+plus_x]);
    xlabel('t'); ylabel(y_Label);   
    hold off;
    legend('cIC', 'dIC'); 
    grid on;
   end 
end

% controls
for i = 1:nu
    y_Label = ['u_' num2str(i)];
    figure
    hold on;
    stairs(1:nsteps,cU(i,:),'m--');
    stairs(1:nsteps,dU(i,:),'b');
    ([1,nsteps,-(2+plus_u),(2+plus_u)]); grid on;
    xlabel('t'); ylabel(y_Label);
    hold off; 
    legend('cIC', 'dIC'); 
    grid on;
end
