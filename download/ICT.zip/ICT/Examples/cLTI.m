% H. N. Nguyen, P.- O. Gutman, R. Bourdais
% More efficient interpolating control
% Example 1

% System matrices:    A \in R^{6x6},
%                     B \in R^{6x2};
% State constraints:  -4 <= x1 <= 4, -4 <= x3 <= 4, -4 <= x5 <= 4;
% Control constraints:-.5 <= u1 <= .5, -.5 <= u2 <= .5.
warning off
close all
clear all
clc

%State and control matrices
A = [0.7627 0.4596 0.1149 0.0198 0.0025 0.0003;
-0.8994 0.7627 0.4202 0.1149 0.0193 0.0025;
0.1149 0.0198 0.7652 0.4599 0.1149 0.0198;
0.4202 0.1149 -0.8801 0.7652 0.4202 0.1149;
0.0025 0.0003 0.1149 0.0198 0.7627 0.4596;
0.0193 0.0025 0.4202 0.1149 -0.8994 0.7627];

B = [0.1199 0.4596 0.0025 0.0198 0.0000 0.0003;
0.0025 0.0198 0.1199 0.4599 0.0025 0.0198]';


%Weighting matrices
Q = diag([1 0 1 0 1 0]);
R = 0.001 * diag([1 1]);

nx = size(A,2); % Number of states
nu = size(B,2); % Number of inputs

%State constraints
Fx = [1 0 0 0 0 0; 0 0 0 0 0 0;0 0 1 0 0 0; 0 0 0 0 0 0; 0 0 0 0 1 0; 0 0 0 0 0 0;
      -1 0 0 0 0 0; 0 0 0 0 0 0;0 0 -1 0 0 0; 0 0 0 0 0 0; 0 0 0 0 -1 0; 0 0 0 0 0 0;];
gx = [4; 0; 4; 0; 4; 0; 4; 0; 4; 0; 4; 0];
X = [Fx gx];

%Input constraints
Fu = [1 0; 0 1; -1 0; 0 -1];
gu = [0.5; 0.5; 0.5; 0.5];
U = [Fu gu];

%LQR
K = dlqr(A,B,Q,R); % HIGH - gain controller

%New state constraints
Fc = [Fx; -Fu*K];
gc = [gx; gu];

% OMEGA
% Compute the maximal positively invariant set with x4 = 0; x5 = 0; x6 = 0;
display('Computing the inner maximal invariant set...');
[Omega,tstar,fd] = oinfsetcl(A,B,[],X,U,[],-K,20);
F_Omega = Omega(:,1:end-1);
g_Omega = Omega(:,end);
P = Polyhedron(Omega(:,1:3),g_Omega);
display ('DONE.')

% Low - gain control matrix
K1 = [-0.036 0.074 0.012 0.018 0.006 0.002;
      0.025 0.021 -0.029 0.085 0.018 0.020];


% Compute the maximal positively invariant set with x4 = 0; x5 = 0; x6 = 0;
display('Computing the outer maximal invariant set...');
[Phi,tstar,fd] = oinfsetcl(A,B,[],X,U,[],-K1,40);
F_Omega1 = Phi(:,1:end-1);
g_Omega1 = Phi(:,end);
P1 = Polyhedron(Phi(:,1:3),g_Omega1);
display ('DONE.')

figure(1)
plot(P, 'color', 'red')
hold on
plot(P1, 'color','yellow', 'alpha', 0.2)
hold off
title ('Cut through x_4=0, x_5=0, x_6=0')
xlabel('x1')
ylabel('x2')
zlabel('x3')

% initial condition
x0 = [3.0136 2.7106 4.0000 0.3585 3.8636 -3.1652]';
N = 50;

%% IMPROVED INTERPOLATING CONTROL
display('Computing the interpolating control...');

M = 1;          % number of steps necessary for reaching the OMEGA1 set from an outer point

% x    - computed states in N - steps ;
% u - implemented IC for N - steps ;
% s    - computed interpolating coefficient in N - step.
[x, u, s] = cIC(A, B, -K, X, U, Omega, Phi, M, N, x0, []);
display('DONE.')

% FIGURES

figure
for i = 1:nx
    subplot(2,3,i)
    hold on
    stairs(x(i,:))
    axis([0 N -5 5])
    xlabel('Time (sampling)')
    ylabel('x1')
    hold off
    legend('cIC')
end
suptitle ('State trajectories')
  
figure
for i = 1:nu
    subplot(2,1,i)
    hold on
    stairs(u(i,:))
    xlabel('Time (sampling)')
    ylabel('u_1')
    axis([0 N -.55 .55])
    hold off
    legend('cIC')
end

figure(4)
stairs(s,'b')
xlabel('Time (sampling)')
ylabel('s')
axis([0 N -.1 max(s)+0.1])
title ('Interpolating coefficient', 'FontSize', 14, 'FontWeight', 'bold')

















