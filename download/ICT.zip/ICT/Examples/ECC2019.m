%  Example in 
%% Scialanga, Ampountolas - Interpolating control Toolbox (ICT)
%% ECC 2019
%
% from
% H. N. Nguyen, P.- O. Gutman, R. Bourdais
% More efficient interpolating control
% Example 2
% Robust case : time-varying linear discrete time system

% System matrices:    A1 \in R^{2x2},
%                     A2 \in R^{2x2},
%                     B  \in R^{2x1};
% State constraints:  -1 <= x1 <= 1, -1 <= x2 <= 1;
% Control constraints:-1 <= u1 <= 1.
warning off
close all
clear all
clc

% number of realisations
r = 2;

A = cell(r,1);
B = cell(r,1);
%State and control matrices
A{1} = [1 0.1; 0 0.99]; 
A{2} = [1 0.1; 0 0];   

B{1} = [0 0.0787]';   
B{2} = B{1};

nx = size(A{1},2); % Number of states
nu = size(B{1},2); % Number of inputs

%State constraints
Fx = [eye(nx); -eye(nx)];
gx = ones(4,1);
X = [Fx gx];

%Input constraints
Fu = [1; -1];        
gu = [2; 2];          
U = [Fu gu];

%LQR
K = [30.3781 9.6139]; % HIGH - gain controller

% Compute the maximal positively invariant set
display('Computing the maximal invariant set...');
tmax = 20;
[Omega,tstar,fd] = oinfsetcl(A,B,[],X,U,[],-K,tmax);
P = Polyhedron (Omega(:,1:end-1), Omega(:,end));
display ('DONE.')


% Compute the N-step controlled invariant set
display('Computing the N-step controlled invariant set...');
tmax = 66;
tic
[Phi,tstar,fd] = sinfset(A,B,[],X,U,[],Omega,tmax);
T2 = toc;
PN = Polyhedron (Phi(:,1:end-1), Phi(:,end));
display ('DONE.')


x0 = [-0.0370; 0.9875]; % initial condition

figure
plot(P, 'color', 'red')
hold on
plot(PN, 'color','yellow', 'alpha', 0.2)
plot(x0(1), x0(2), 'b*')
hold off
xlabel('x_1')
ylabel('x_2')


%% INTERPOLATING CONTROL

alphas = [0.8257; 0.4445; 0.9821; 0.5783; 0.2344;
         0.8106; 0.4513; 0.2500; 0.9554; 0.1427;
         0.5126; 0.9719; 0.6483; 0.6147; 0.4697;
         0.5778; 0.9113; 0.3762; 0.2288; 0.4235; 
         0.2736; 0.4446; 0.6275; 0.5346; 0.3854;
         0.8735; 0.3003; 0.4000; 0.5177; 0.0618;
         0.2314; 0.1185; 0.0988; 0.8903; 0.0334;
         0.8390; 0.5073; 0.1137; 0.4904; 0.5994];

display('Computing the interpolating control...')
N = 40;
[x, u, s] = cIC(A, B, -K, X, U, Omega, Phi, [], N, x0, alphas);
display('DONE.')


% FIGURES

figure
for i = 1:nx
    subplot(2,1,i)
    stairs(x(i,:))
    axis([1 N min(x(i,:))-0.1 max(x(i,:))+0.1])
    xlabel('Time (sampling)')
    ylabel(['x_{' num2str(i) '}'])
end
suptitle('State trajectories')
  
figure
for i = 1:nu
    stairs(u(i,:))
    axis([1 N min(u(i,:))-0.1 max(u(i,:))+0.1])
    xlabel('Time (sampling)')
    ylabel(['u_{' num2str(i) '}'])
end
title('Input trajectories')


figure(5)
stairs(s)
xlabel('Time (sampling)')
ylabel('s')
axis([1 N -.1 max(s)+0.1])
title ('Interpolating coefficient', 'FontSize', 14, 'FontWeight', 'bold')

figure(6)
stairs(alphas, 'b')
xlabel('Time')
ylabel('\alpha')
title('\alpha realisation')


