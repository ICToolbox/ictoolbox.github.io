% % Example in 
%% Scialanga, Ampountolas - 
%% Interpolating Constrained Control of Interconnected Systems
%% CTS 2018
% %
% % from
% % from Veillette, R., Medanic, J., and Perkins, W. (1992).
% % Design of a reliable control systems. IEEE Transactions on
% % Automatic Control, 37, 280–304.

% The discrete-time system matrices have been ob-
% tained assuming zero-order hold sampling at the inputs
% with a sampling period equal to 0.1.
% To obtain an input-decentralised
%  decoupled system with distinct inputs, the
% controllable canonical form has been calculated.

clear all
close all
clc
warning off


Ac{1} = [0       1.0000         0         0;
   -0.7960    1.8149         0         0;
         0         0         0    1.0000;
         0         0   -0.7688    1.6578];

Bc{1} = [ 0         0;
      1.0000    0;
      0         0;
      0    1.0000];
   
no_subs = 2; % number of subsystems
r = 1; % realisations

nx = size(Ac{1},2);
n = zeros(no_subs,1);
n(1) = 2;
n(2) = 2;

nu = size(Bc{1},2);
m = zeros(no_subs,1);
m(1) = 1;
m(2) = 1;


Q = eye(nx);      
R = 0.00001 * eye(nu); 


% LOCAL state and control contraints
Xmax = 1 * ones(no_subs,1); Umax = 0.1 * ones(no_subs,1);
Fx = cell(no_subs,1);
Fu = cell(no_subs,1);
gx = cell(no_subs,1);
gu = cell(no_subs,1);
X = cell(no_subs,1);
U = cell(no_subs,1);
for i = 1 : no_subs
    Fx{i} = [eye(n(i)); - eye(n(i))];
    Fu{i} = [eye(m(i)); - eye(m(i))];
    gx{i} = [Xmax(i) * ones(2*n(i),1)];
    gu{i} = [Umax(i) * ones(2*m(i),1)];
    X{i} = [Fx{i} gx{i}];
    U{i} = [Fu{i} gu{i}];
end


% initial state
x0 = [0.7986 0.0990 -0.5520 0.28]';
% time steps
nsteps = 20;


%% centralised IC
str = sprintf('\n\n>>>centralised IC<<<\n');
disp(str);

% State constraints
Fxc = blkdiag(Fx{:});
gxc = cat(1, gx{:});
Xc = [Fxc gxc];

% 
% %Input constraints
Fuc = blkdiag(Fu{:});
guc = cat(1, gu{:});
Uc = [Fuc guc];

% LQR
KC = dlqr(Ac{1},Bc{1},Q,R);


% OMEGA
% Compute the maximal positively invariant set
display('Computing the inner maximal invariant set...');
[OmegaC,tstar,fd] = oinfsetcl(Ac{1},Bc{1},[],Xc,Uc,[],-KC,20); % tstar = 3
% F_OmegaC = [0.7960   -1.8149    0.0000    0.0000
%             0.0000    0.0000    0.7688   -1.6578
%            -0.7960    1.8149   -0.0000   -0.0000
%            -0.0000   -0.0000   -0.7688    1.6578
%             0.0000    0.7960   -0.0000   -0.0000
%            -0.0000   -0.7960    0.0000    0.0000
%             0.0000    0.0000   -0.0000   -0.7688
%            -0.0000   -0.0000    0.0000    0.7688];
% g_OmegaC = [0.1000
%             0.1000
%             0.1000
%             0.1000
%             0.1000
%             0.1000
%             0.1000
%             0.1000];
F_OmegaC = OmegaC(:,1:end-1);
g_OmegaC = OmegaC(:,end);
PC = Polyhedron(F_OmegaC(:,1:3),g_OmegaC);
display ('DONE.')

% PHI
% Compute the maximal positively invariant set
display('Computing the outer maximal invariant set...');
tmax = 10; % tstar = 10
% [PhiC,tstar,fd] = sinfset(Ac{1},Bc{1},[],Xc,Uc,[],Omega,tmax); % PN 
F_PhiC = [
         0         0    0.7688   -1.6578
         0         0   -0.7688    1.6578
         0         0         0   -1.0000
         0         0         0    1.0000
         0         0    1.2745   -1.9795
         0         0    1.5218   -2.0071
         0         0   -1.2745    1.9795
         0         0   -1.5218    2.0071
    0.7960   -1.8149         0         0
   -0.7960    1.8149         0         0
         0   -1.0000         0         0
         0    1.0000         0         0
    1.4447   -2.4979         0         0
    1.9883   -3.0887         0         0
    2.4586   -3.6174         0         0
   -1.4447    2.4979         0         0
   -1.9883    3.0887         0         0
   -2.4586    3.6174         0         0
    1.0000         0         0         0
         0         0    1.0000         0
   -1.0000         0         0         0
         0   -1.0000         0         0
         0         0   -1.0000         0];
g_PhiC = [    
    1.1000
    1.1000
    1.0000
    1.0000
    1.2658
    1.4637
    1.2658
    1.4637
    1.1000
    1.1000
    1.0000
    1.0000
    1.2815
    1.5313
    1.8401
    1.2815
    1.5313
    1.8401
    1.0000
    1.0000
    1.0000
    1.0000
    1.0000];
% F_Omega1C = Phi(:,1:end-1);
% g_Omega1C = Phi(:,end);
PhiC = [F_PhiC g_PhiC];
P1C = Polyhedron(F_PhiC(:,1:3),g_PhiC);
display ('DONE.')

figure
plot(PC, 'color', 'red')
hold on
plot(P1C, 'color','yellow', 'alpha', 0.2)
plot3(x0(1), x0(2), x0(3),'*')
hold off
title ('Invariant sets (centralised system)', 'FontSize', 14, 'FontWeight', 'bold')
xlabel('x1')
ylabel('x2')
zlabel('x3')


display('Computing the centralised interpolating control...');
 
% allocate history matrices
cX = zeros(nx,nsteps);  % state
cU = zeros(nu,nsteps);  % input
 
% x    - computed states in N - steps ;
% u    - implemented IC for N - steps ;
% s    - computed interpolating coefficient in N - step.

[cX, cU, cS] = cIC(Ac{1}, Bc{1}, -KC, Xc, Uc, OmegaC, PhiC, [], nsteps, x0, []);
display('DONE.')


%% decentralised IC
str = sprintf('\n\n>>>decentralised IC<<<\n');
disp(str);

A = cell(1, no_subs);
B = cell(1, no_subs);
[A, B, ~] = cen2dec(Ac,Bc, n, m); 

Omega = cell(1,no_subs);
Phi = cell(1,no_subs);
P = cell(1,no_subs);
P1 = cell(1,no_subs);

Q = cell(1, no_subs);
R = cell(1, no_subs);
K = cell(1, no_subs);

for i = 1: no_subs
   
 
   % Weighting matrices
   Q{i} = eye(n(i));
   R{i} = 0.00001 * eye(m(i));
   K{i} = -dlqr(A{i,1},B{i,1},Q{i},R{i});
       
   % Compute the maximal positively invariant set
   display('Computing the inner maximal invariant set...');
   [Omega{i},tstar,fd] = oinfsetcl(A{i,:},B{i,:},[],X{i},U{i},[],K{i},20);
   F_Omega{i} = Omega{i}(:,1:end-1);
   g_Omega{i} = Omega{i}(:,end);
   P{i} = Polyhedron(F_Omega{i},g_Omega{i});
   display ('DONE.')

   % Compute the N-step controlled invariant set
   display('Computing the outer controlled invariant set...');
   [Phi{i},tstar,fd] = sinfset(A{i,:},B{i,:},[],X{i},U{i},[],Omega{i},tmax); %PN
   F_Phi{i} = Phi{i}(:,1:end-1);
   g_Phi{i} = Phi{i}(:,end);
   P1{i} = Polyhedron (F_Phi{i}, g_Phi{i}(:,end));
   display ('DONE.')

   label_x = ['x' num2str(sum(n(1:i)) -1)];
   label_y = ['x' num2str(sum(n(1:i)))];
   figure
   plot(P{i}, 'color', 'red')
   hold on
   plot(P1{i}, 'color','yellow', 'alpha', 0.2)
   plot(x0(sum(n(1:i) -1)), x0(sum(n(1:i))),'*')
   hold off
   str = sprintf('Invariant sets S%d',i);
   title (str, 'FontSize', 14, 'FontWeight', 'bold')
   xlabel(label_x)
   ylabel(label_y)

end

display('Computing the decentralised interpolating control...');
M = 1;          % number of steps necessary for reaching the OMEGA1 set from an outer point

% allocate history matrices
dX = zeros(nx,nsteps+1); % state
dU = zeros(nu,nsteps); % input
dS = zeros(no_subs,nsteps);

[dX, dU, dS] = dIC(A, B, [], K, X, U, [], Omega, Phi, nsteps, x0, []);

display('DONE.')

%% FIGURES
tvec = 0:nsteps;
plus_x = 0.2;
plus_u = 0.05;

figure
for i = 1:nx
    subplot(3,2,i); 
    hold on;
    stairs(tvec,cX(i,:), 'k--');
    stairs(tvec,dX(i,:), 'm-');
    axis([0,nsteps,-(1+plus_x),1+plus_x]);
    xlabel('t'); ylabel(['x_{' num2str(i) '}']);
    plot(tvec, 1 * ones(size(tvec)),'r');
    plot(tvec, -1 * ones(size(tvec)),'r');
    hold off; 
    legend('cIC', 'dIC'); 
    grid on;
end 


for i = 1: nu
    subplot(3,2,i+nx); 
    hold on;
    stairs(1:nsteps,cU(i,:), 'k--');
    stairs(1:nsteps,dU(i,:), 'm-');
    axis([1,nsteps,-(0.1+plus_u),(0.1+plus_u)]); grid on;
    set(gca,'yTick',-1:.2:1);
    xlabel('t'); ylabel(['u_{' num2str(i) '}']);
    plot(tvec, 0.1 * ones(size(tvec)),'r');
    plot(tvec, -0.1 * ones(size(tvec)),'r');
    hold off; 
    legend('cIC', 'dIC'); 
    grid on;
end

suptitle('State and input evolution')

% interpolating coefficients

figure
stairs(cS,'b-v')
hold on;
stairs(dS(1,:), 'r-x')
stairs(dS(2,:), 'k-*')
xlabel('Time')
ylabel('s')
ymax = max(max(dS));
axis([1 nsteps -.1 ymax+0.1]);
grid on;
legend('cS', 'dS_1', 'dS_2')


