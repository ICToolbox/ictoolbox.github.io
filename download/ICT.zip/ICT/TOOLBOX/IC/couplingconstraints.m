function W = couplingconstraints(Fx, gx)

no_subs = length(Fx);

for i = 1:no_subs
   W{i} = [blkdiag(Fx{1:i-1}, Fx{i+1:no_subs}) cat(1,gx{1:i-1}, gx{i+1:no_subs})];
end
