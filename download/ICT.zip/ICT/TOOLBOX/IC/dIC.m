function [Xhist, Uhist, computedS] = dIC(A, B, D, K, X, U, W, Omega, Phi, N, x0, alphas)


    if isempty(alphas)
        alphas = ones(N,1);
    end

[no_subs,r] = size(A);

if r == 2
    alphas = [alphas 1-alphas];
end

Fx = cell(no_subs,1);
gx = cell(no_subs,1);
Fu = cell(no_subs,1);
gu = cell(no_subs,1);
Fw = cell(no_subs,1);
gw = cell(no_subs,1);
F0 = cell(no_subs,1);
g0 = cell(no_subs,1);
F1 = cell(no_subs,1);
g1 = cell(no_subs,1);
n = zeros(no_subs,1);
m = zeros(no_subs,1);
p = zeros(no_subs,1);

for i = 1:no_subs   
    Fx{i} = X{i}(:,1:end-1);
    gx{i} = X{i}(:,end);
    Fu{i} = U{i}(:,1:end-1);
    gu{i} = U{i}(:,end);
    F0{i} = Omega{i}(:,1:end-1);
    g0{i} = Omega{i}(:,end);
    F1{i} = Phi{i}(:,1:end-1);
    g1{i} = Phi{i}(:,end);
    n(i) = size(A{i,1},2);
    m(i) = size(B{i,1},2);   
     if ~isempty(W)
        Fw{i} = W{i}(:,1:end-1);
        gw{i} = W{i}(:,end);
        p(i) = size(D{i,1},2);
    end
end
nx = sum(n); % Number of states
nu = sum(m); % Number of inputs

x = cell(1, no_subs);



for i = 1: no_subs
    app = cell(r,1);
    F1new = cell(r,1);
    g1new = cell(r,1);
    for j = 1:r
       g1new{j} = g1{i};
       if ~isempty(W)
            % \Omega_1 + (-D * W)    [F_1 * (A * x + B * u) <= g1 - max_{w \in W} F1 * D * w]
            app{j} = pdiff([F1{i} g1{i}],W{i},D{i,j});
            F1new{j} = app{j}(:, 1:end-1);
            g1new{j} = app{j}(:, end);

        end
    end
   
   % initial state cell
    x{i} = x0(sum(n(1:i-1))+1:sum(n(1:i)));
    
    f{i} = [1 zeros(1, n(i) + m(i))];
    FM = []; 
    gM = []; 

    for j = 1:r
        FM = [FM; F1{i} * [A{i,j} B{i,j}]];
        gM = [gM; g1new{j}]; % x0 reaches Omega1 in 1 step
    end 


    Aineq{i} = [ [1; -1]        zeros(2, n(i) + m(i))                                      ;   % 0 <= s <= 1
                  g0{i}             -F0{i}                   zeros(length(g0{i}), m(i));     % g0 * s - F0 * rm <= g0 - F0 * x
                  -gM                FM                                                    ;     % FM * [rm VM] <= s * gM
                  -gu{i}             zeros(length(gu{i}), n(i))      Fu{i}                           ];   % Fu * vi <= s * gu  (FU * VM <= s * GU)
    
    
    tDecIC{i} = toc;
end

Xhist = zeros(nx,N+1);        % computed states in N - steps ;
Uhist = [];                     % implemented IC for N - steps ;
implementedW = [];              % implemented disturbances for N - steps ;
computedS = [];                 % computed interpolating coefficient in N - steps.
computedR0 = [];
computedV1 = [];

% initial state
Xhist(:,1) = x0;

fprintf('\n Computing decentralised interpolating control for %d -th subsystem...\n',i);
% Computes ROBUST interpolating control

for j = 1:N
    UU = [];   
    WW = [];
    XX = [];
    SS = [];
    RR0 = [];
    VV1 = [];
    
    for i = 1: no_subs
        
        bineq = [1; 0; g0{i} - F0{i} * x{i}; zeros(r*size(F1{i},1),1); zeros(length(gu{i}),1)];
        % include Algorithm options in linprog for MATLAB 2016a and below        
        % options = optimoptions('linprog','Algorithm','active-set');
        solution = linprog(f{i},Aineq{i},bineq);%,[],[],[],[],[],options);
        s = solution(1);
        r0 = x{i} - solution(2 : n(i)+1);              % r0 = x - rm
        v1 = solution(n(i) + 2 : n(i) + m(i) + 1);      % v1 = s * u1
        v0 = K{i} * r0;                              % v0 = ( 1-s ) * K *x0 , u0 = K * x0
        U = v1 + v0;                              % U = s * u1 + (1 - s) * u0
        if ~isempty(W)
            w = [Xhist(1:sum(n(1:i-1)),j); Xhist(sum(n(1:i))+1:end,j)];            
            AA = zeros(n(i)); BB = zeros(n(i),m(i)); DD = zeros(n(i),p(i));
            for l = 1:r
                AA = AA + alphas(j,l) * A{i,l};
                BB = BB + alphas(j,l) * B{i,l};
                DD = DD + alphas(j,l) * D{i,l};
            end
            x{i} = AA * x{i} + BB * U + DD * w;
            WW = [WW w'];
        else
            AA = zeros(n(i)); BB = zeros(n(i),m(i));
            for l = 1:r
                AA = AA + alphas(j,l) * A{i,l};
                BB = BB + alphas(j,l) * B{i,l};
            end
            x{i} = AA * x{i} + BB * U;
        end
        UU = [UU U'];       
        XX = [XX x{i}'];
        SS = [SS s];
        RR0 = [RR0 r0'];
        VV1 = [VV1 v1'];       
    end
     
    
     Uhist = [Uhist UU'];
     Xhist(:,j+1) = XX';
     implementedW = [implementedW WW'];
     computedR0 = [computedR0 RR0'];
     computedV1 = [computedV1 VV1'];
     computedS = [computedS SS'];
end
