function [Ac, Bc] = dec2cen(A, B, D, n, m) 

no_subs = size(A,1);
q = size(A,2);
nx = sum(n);
nu = sum(m);
Ac = cell(q, 1); 
Bc = cell(q, 1);

for j = 1:q
    
    Ac{j} = zeros(nx);
    Bc{j} = zeros(nx,nu);
    nn = 0;
    mm = 0;
    for i=1:no_subs
        Ac{j}(nn+1:nn+n(i),nn+1:nn+n(i)) = A{i,j};
        Bc{j}(nn+1:nn+n(i),mm+1:mm+m(i)) = B{i,j};
        Ac{j}(nn+1:nn+n(i), 1:nn) = D{i,j}(:,1:nn);
        Ac{j}(nn+1:nn+n(i), nn+n(i)+1:nx) = D{i,j}(:,nn+1:end);
        nn = nn + n(i);
        mm = mm + m(i);
    end
    
end
