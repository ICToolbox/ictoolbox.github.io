function [computedX, implementedU, computedS] = cIC(A, B, K, X, U, Omega, Phi, M, N, x0, alphas)
% cIC       Calculates centralised interpolating control for 
%           LTI/LTV systems subject to polytopic constraints.
%
%   Usage:
%     [computedX, implementedU, computedS] = cIC(A, B, K, Fx, gx, Fu, gu, Omega, Phi, M, N, x0, alphas)
%
%   Inputs:
%      A,B:     The A and B matrices of the system 
%                 x(k+1) = A(k) x(k) + B(k) u(k).
%               The matrices A(k) and B(k) are time-varying matrices
%               defined as
%               A(k) = \sum_{l=1}^N alpha^{(l)}(k) A^{(l)}, with  A^{(l)} \in R^{n x n}
%               B(k) = \sum_{l=1}^N alpha^{(l)}(k) B^{(l)}, with  B^{(l)} \in R^{n x m}
%
%      K:       High - gain control matrix.
%      Fx,gx:   Fx \in R^{2*n x n}, gx \in R^{2*n} define the state
%               polytopic constraints :
%               x(k) \in X, X = {x \in \R^n : Fx * x <= gx}.
%      Fu,gu:   Fu \in R^{2*m x m}, gu \in R^{2*m} define the control
%               polytopic constraints :
%               u(k) \in U, U = {u \in \R^m : Fu * u <= gu}.
%      F0, g0:  F0 \in R^{p x n}, g0 \in R^{p} define the Maximal
%               Admissible Set (MAS) for the system:
%               Omega = {x \in R^n : F0 * x <= g0}
%      F1, g1:  F1 \in R^{p1 x n}, g1 \in R^{p1} define the outer set for the
%               systems (either the Maximal controllable invariant set, the
%               M-step controllable set or a MAS of some low-gain matrix):
%               Phi = {x \in R^n : F1 * x <= g1}
%      M:       Horizon. Number of steps necessary for reaching Phi
%               from a point outside Phi. (only for LTI systems)
%      N:       Number of iterations.
%      x0:      x0 \in R^n. Initial condition.
%
%   Outputs:
%     computedX:    computedX \in R^{n x N}. Computed state in N - steps.   
%     implementedU: implementedU \in R^{m x N}. Implemented cIC for N -
%                   steps:
%                   u(k) = s(k) * u_1(k) + (1 - s(k)) * u_0(k)
%     computedS:    computedS \in R^N.
%                   Interpolating coefficient in N - steps.
%                   s(k) is a decresing function.
%
% 
%
% Invariant Set Toolbox
% Date: 01/11/2018

if isempty(M)
     M = 1;
end
if isempty(alphas)
     alphas = ones(N,1);
end


[n,m] = size(A);
if n == m
	r = 1;
    Ac = cell(r, 1);
    Bc = cell(r, 1);
    Ac{1} = A;
    Bc{1} = B;
else
	r = length(A);
    Ac = cell(r, 1);
    Bc = cell(r, 1);
    Ac = A;
    Bc = B;
end

if r == 2
    alphas = [alphas 1-alphas];
end

Fx = X(:,1:end-1);
gx = X(:,end);
Fu = U(:,1:end-1);
gu = U(:,end);
F0 = Omega(:,1:end-1);
g0 = Omega(:,end);
F1 = Phi(:,1:end-1);
g1 = Phi(:,end);

nx = size(Fx,2); % Number of states
nu = size(Fu,2); % Number of inputs




% s \in R, ro,rm \in R^n, Vm \in R^{m*M}
% rm + r0 = x --> r0 = x - rm
% solution = [s rm Vm]; 
% Define matrices for the linear programming solver

% objective min_{solution} f^T {solution}; min_{s, rm, Vm} s
f = [1 zeros(1, nx + nu * M)];


% A * solution <= b: 
%                    g0 * s - F0 * rm <= g0 - F0 * x,
%                        FM * [rm VM] <= s * gM, 
%                             Fu * vi <= s * gu  (FU * VM <= s * GU)
%                              0 <= s <= 1

% [F1 * (A{j} * x + B{j} * u) <= GM] 
% r number of realisations
l = length(g1);
FM = [];

if M == 1
    for j = 1:r
    FM = [FM; F1 * [Ac{j} Bc{j}]]; 
    end    
else
    FMapp = [Ac{r} Bc{r}];
end

if M == 1
    gM = repmat(g1,j,1); % x0 reaches Phi in 1 step
else
    FM = [Fx * FMapp zeros(size(Fx,1),(M-1)*nu)];
    gM = gx;       % x0 reaches Phi in more than 1 step

end

% r = 1
for i = 2:M-1          
        FMapp = [Ac{r} * FMapp Bc{r}];
        FM = [FM; Fx * FMapp zeros(nx, (M-i)*nu)];
        gM = [gM; gx];
end
if M > 1
        FMapp = [Ac{r} * FMapp Bc{r}];
        FM = [FM; F1 * FMapp];
        gM = [gM;g1];
end
% control constraints
FU = kron(eye(M),Fu);
GU = kron(ones(M,1),gu);

Aineq = [ [1; -1]        zeros(2, nx + M*nu)                                      ;  % 0 <= s <= 1
          g0                       -F0                   zeros(length(g0), nu * M);  % g0 * s - F0 * rm <= g0 - F0 * x
         -gM                FM                                                    ;  % FM * [rm VM] <= s * gM
         -GU             zeros(length(GU), nx)      FU                           ];  % Fu * vi <= s * gu  (FU * VM <= s * GU)
     
     
% Initial state
x = x0;

computedS = [];
computedX = x;
implementedU = [];


% Implement N - steps
for i = 1:N
    bineq = [1; 0; g0 - F0 * x; zeros(length(gM),1); zeros(length(GU),1)];
    % include Algorithm options in linprog for MATLAB 2016a and below        
    % options = optimoptions('linprog','Algorithm','active-set');
    solution = linprog(f,Aineq,bineq);
    s = solution(1);
    r0 = x - solution(2 : nx+1);              % r0 = x - rm
    v1 = solution(nx + 2 : nx + nu + 1);      % v1 = s * u1
    v0 = K * r0;                              % v0 = ( 1-s ) * K *x0 , u0 = K * x0
    U = v1 + v0;                              % U = s * u1 + (1 - s) * u0
    AA = zeros(nx); BB = zeros(nx,nu);
    for j = 1:r
       AA = AA + alphas(i,j) * Ac{j};
       BB = BB + alphas(i,j) * Bc{j};
    end
    x = AA * x + BB * U;
    implementedU = [implementedU U];
    computedX = [computedX x];
    computedS = [computedS s];
end

end
