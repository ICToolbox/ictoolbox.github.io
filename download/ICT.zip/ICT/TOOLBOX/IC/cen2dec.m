function [A, B, D] = cen2dec(Ac,Bc, n, m) 

no_subs = length(n);
r = length(Ac);
nx = size(Ac{1},1);

A = cell(no_subs,r);
B = cell(no_subs,r);
D = cell(no_subs,r);
nn = 0; 
mm = 0 ;

for i=1:no_subs
    
    for j = 1:r
        A{i,j} = Ac{j}(nn+1:nn+n(i),nn+1:nn+n(i));
        B{i,j} = Bc{j}(nn+1:nn+n(i),mm+1:mm+m(i));
        D{i,j} = [Ac{j}(nn+1:nn+n(i), 1:nn) Ac{j}(nn+1:nn+n(i), nn+n(i)+1:nx) ] ;
    end
    nn = nn + n(i);
    mm = mm + m(i);
end
