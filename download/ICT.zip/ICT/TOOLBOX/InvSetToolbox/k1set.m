function K1 = k1set(A,B,X,U,T,cap,E,W)
% K1SET Calculates the intersection between the robust one-step set
%          and the state constraints to form the robust one-step
%          controllable set.
%
%   Usage: 
%     K1 = k1set(A,B,X,U,T,cap,E,W)
%   
%   Inputs:
%     A,B,E:  State space matrices of the discrete-time 
%             LTI system x_{k+1} = A*x_k + B*u_k + E*w_k.
%             For polytopic uncertainty, stack vertices 
%             of uncertainty sets for A and B on top of each other.
%             The inclusion of E is optional.
%     X:      State constraints in augmented form.
%     U:      Control constraints in augmented form.
%     T:      Target set in augmented form.
%     cap:    Optional - Intersects one-step set with X.
%             1 if desired that the output be
%               K1 = {x \in X | \exists u \in U: Ax+Bu \in T} (default).
%             0 if desired that the output be
%               K1 = {x \in \Real^n | \exists u \in U: Ax+Bu \in T}.
%     
%     W:      Optional - State disturbance set in augmented form
%
%   Outputs: 
%     K1:   Robust one-step controllable set
%           
%   See also STD2AUG, AUG2STD, KINFSET, ONESTEPAUT
%
% Invariant Set Toolbox
% Version 0.10.2, Date: 20/7/2001
% Copyright (c) by Eric Kerrigan
%
% Edited by Sheila Scialanga

% n: number of states
% m: number of inputs
[rA,n]=size(A{1});
[rB,m]=size(B{1});


[n1,m1] = size(A);
if n1 == m1
    N = 1;
else
    N = length(A); % number of realisations
end
Ti = cell(1,N);

if nargin >= 6
  if isempty(cap)
	cap = 1;
  end
else
  cap = 1;
end

for i = 1 : N
    Ti{i} = T;
end 

if nargin >= 8
  if ~isempty(W) 
      for i = 1:N
        Ti{i} = pdiff(Ti{i},W,E{i});
      end
  end
end


K1 = [];

Q = cell(N,1);
Q1 = cell(N,1);
q2 = cell(N,1);       

for i = 1:N
    % Q = inv(A) * [T + (-B * U)]
     if m == n & isequal(B{i},eye(n))
        Q{i} = polysum(Ti{i},scaleset(-1,U{i})); %Q = polysum(T,scaleset(-1,U));
        [Q1{i},q2{i}] = aug2std(Q{i});
        Q{i} = std2aug(Q1{i}*A{i},q2{i});
     else
        Q{i} = polysum(Ti{i},polymap(-B{i},U{i}));
        [Q1{i},q2{i}] = aug2std(Q{i});
        Q{i} = std2aug(Q1{i}*A{i},q2{i});
     end
    % Intersect with X
    if cap == 1
        Q{i} = [Q{i};X];
    end
    [Q1{i},q2{i}] = aug2std(Q{i});
    [Q1{i},q2{i}] = remred(Q1{i},q2{i}); % Remove redundant inequalities
    K1 = [K1; std2aug(Q1{i},q2{i})];
   end  



