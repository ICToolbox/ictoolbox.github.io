function [Oinf,tstar,fd] = oinfset(A,E,X,W,tmax)
% OINFSET Calculates the maximal positively invariant set for an
%           autonomous discrete-time LTV system
%
%   Usage: 
%     [Oinf,tstar,fd] = oinfset(A,E,X,W,tmax)
%
%   Inputs:
%     A: The A matrix of the discrete-time system x_{k+1} = Ax_k + Ew_k.
%     E: Disturbance matrix.
%     X: State constraints in augmented form.
%     W: Disturbance constraints in augmented form.
%     tmax: Maximum number of iterations allowed.
% 
%   Outputs:
%     Oinf:  Maximal positively invariant set contained in X, i.e.
%              Oinf = {x_0 \in X: x_k \in X for all w_k \in W, k > 0}.
%     tstar: Determinedness index.
%     fd:    1 if Oinf is finitely determined (tstar <= tmax).
%            0 if Oinf tstar > tmax.
%
%   See also AUG2STD, STD2AUG, ONESTEPAUT, OINFSETCL, OINFDIST, KINFSET
%
%
% Invariant Set Toolbox
% Version ---, Date: 10/7/2017
% Copyright (c) by Eric Kerrigan
%
% Edited by Sheila Scialanga

% Reference: E.G. Gilbert and K.T. Tan, "Linear systems with state and
% control constraints: The theory and application of maximal output
% admissible sets
%
%F. Borrelli, A. Bemporad, M. Morari, "Predictive Control for linear 
% and hybrid systems"

[n,m] = size(A);
if n == m
	N = 1;
    Ac = cell(N, 1);
    Ac{1} = A;
    if ~isempty(W) 
        Ec = cell(N, 1);
        Ec{1} = E;
    end
else
	N = length(A);
    Ac = cell(N, 1);
    Ac = A;
    if ~isempty(W) 
        Ec = cell(N, 1);
        Ec = E;
    end
end

[H,h] = aug2std(X);
[H,h] = remred(H,h);
s = length(h);


Hw = H; 
hw = h;

Hwj = [];
hwj = [];

HH = H;
hh = h;

t = 0;
fd = 0;


while (fd == 0) & (t+1 <= tmax)
  disp(sprintf('\nCalculating %d, tmax = %d',t+1,tmax))
  fd = 1;
  
  t = t + 1;
  Happ = [];
  happ = [];
  for j = 1:N
        hwj = hw;
        if ~isempty(W) 
            Hwj = pdiff([Hw hw],W,Ec{j}); % Oinf(t) - (E * W)
            hwj = Hwj(:,end);
        end
        Hnew = Hw * Ac{j}; % Pre_j(Oinf(t),W) Hwi{j} = Hw
        Happ = [Happ; Hnew]; % intersection of Pre_j(Oinf(t),W), i.e. all the realisations of A{j}
        happ = [happ; hwj];
        for i = 1:s
            if ~isredundant([HH; Hnew(i,:)],[hh; hwj(i)],length(hh)+1) % Pre(Oinf(t),W) \intersect Oinf(t)
      			fd = 0; % if new constraint not redundant then not finished yet
      			HH = [HH; Hnew(i,:)]; % and add new constraint to previous constraints
      			hh = [hh; hwj(i)];
            end
        end
  end

  
  
% Hnew = H * A{j}^t.
% at each step, Pre_j is the set: Pre(Oinf(t),W) \intersect Pre(Oinf(t-1),W)
% We save the current Omega_{MAX} in [HH hh].
% We multiply the new matrix with the A realisations. DO NOT use the full
% [HH hh] because it would be a repetition on the values.
    Hw = Happ;
    hw = happ;
    s = length(hw);
 
end

[HH,hh] = remred(HH,hh);

Oinf = std2aug(HH,hh);

if fd == 1
  tstar = t-1;
else
  tstar = t;
end
