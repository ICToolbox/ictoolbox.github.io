function [Kinf,tstar,fd] = kinfset(A,B,E,X,U,W,T,tmax)
% KINFSET Calculates robust controllable sets for 
%           a discrete-time LTI system, subject to polytopic uncertainty 
%           and state disturbances
%
%   Usage:
%     [Kinf,tstar,fd] = kinfset(A,B,E,X,U,W,T,tmax)
%
%   Inputs:
%      A,B,E:  The A and B matrices of the system 
%                x_{k+1} = Ax_k + Bu_k + Ew_k.
%              For polytopic uncertainty, stack vertices 
%              of uncertainty sets for A and B on top of each other.
%      X:      State constraints in augmented form.
%      U:      Control constraints in augmented form.
%      W:      Disturbance set in augmented form.
%      T:      Target set in augmented form.
%                Default is X for computing the maximal lambda-contractive
%                  (robust control invariant) set.
%      tmax:   Maximum number of iterations.
%      
%
%   Outputs:
%     Kinf:  Kinf is the robust control invariant set contained in X.
%             
%     fd:    0 if tstar > tmax.
%            1 if Kinf is finitely determined (tstar <= tmax). 
%            2 if Kinf is empty.
%            3 if the origin is not in the interior of Kinf (not a C-set).
%
%   See also AUG2STD, STD2AUG, K1SET, CINFSET, SINFSET, OINFSET, OINFDIST
%
% Invariant Set Toolbox
% Version 0.10.2, Date: 20/7/2001
% Copyright (c) by Eric Kerrigan
%
% Edited by Sheila Scialanga

if isempty(T)
  T = X;
  TandXequal = 1;
else
  TandXequal = isequal(T,X);
end

[n,m] = size(A);
if n == m
	[rA,cA] = size(A);
    N = 1;
	A1 = cell(N,1);
	A1{1} = A;
	B1 = cell(N,1);
	B1{1} = B;
   if ~isempty(W)
       E1 = cell(N,1);
       E1{1} = E;
   else
       E1{1} = [];
   end
else
	[rA,cA] = size(A{1});
	N = length(A);
	A1 = cell(N,1);
	A1 = A;
	B1 = cell(N,1);
	B1 = B;
   if ~isempty(W)
       E1 = cell(N,1);
       E1 = E;
   else
       for i = 1:N
           E1{i} = [];
       end
   end
end


UU = cell(length(B1),1);
if rA == cA
  [n,m]=size(A1{1});
  for i = 1 : length(B1)
    UU{i} = polymap(B1{i},U);
    B1{i} = eye(n);
  end
end

t = 1;
fd = 0;
D0 = T;
[rA,n]=size(A1{1});
[rB,m]=size(B1{1});


while t <= tmax & fd == 0
  disp(sprintf('\n*Calculating controllable sets: Step %d of %d\n',t,tmax))

  D1 = k1set(A1,B1,X,UU,D0,1,E1,W);
									   
  if ~isempty(W) & (fd == 0)
	if isemptyset(D1)
		  fd = 2;
		  D1 = [];
		  warning('**THE NEW SET IS EMPTY**')
	else
      if ~is0inint(D1) % if not a C-set
		fd = 3;
		warning('**THE ORIGIN IS NOT IN THE INTERIOR OF THE NEW SET**')
	  end
	end
  end
				
  if fd == 0                
      app0 = Polyhedron(D0(:, 1:end-1), D0(:,end));
      app1 = Polyhedron(D1(:, 1:end-1), D1(:,end));
      if (app0 == app1)
          fd = 1;
      end
	  if fd == 1
	    t = t - 1;
      end
  end
  
  D0 = D1;
  t = t + 1; 
end

Kinf = D1;
tstar = t - 1;
