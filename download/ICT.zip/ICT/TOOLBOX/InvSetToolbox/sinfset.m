function [Sinf,tstar,fd] = sinfset(A,B,E,X,U,W,T,tmax)
% SINFSET Calculates the maximal stabilisable set for a discrete-time LTI system
%
%    Usage: 
%      [Sinf,tstar,fd] = sinfset(A,B,E,X,U,W,T,tmax)
%
%   Inputs:
%      A,B,D:  The A and B matrices of the system x_{k+1} = Ax_k + Bu_k + Ew_k.
%      X:    State constraints in augmented form.
%      U:    Control constraints in augmented form.
%      W:    Disturbance constraints in augmented form.
%      T:    Control invariant target set in augmented form.
%      tmax: Maximum number of iterations.
%      
%
%   Outputs:
%     Sinf:  Maximal stabilisable set contained in X.
%     tstar: Determinedness index.
%     fd:    1 if Cinf finitely determined (tstar <= tmax).
%            0 if tstar > tmax
%
%   See also AUG2STD, STD2AUG, KINFSET, CINFSET, K1SET
%
%   Note: Use KINFSET to compute the maximal *robust
%         lambda-contractive stabilisable set. 
%
% Invariant Set Toolbox
% Version 0.10, Date: 23/3/2001
% Copyright (c) by Eric Kerrigan
%
% Edited by Sheila Scialanga

[Sinf,tstar,fd] = kinfset(A,B,E,X,U,W,T,tmax);