function [Oinf,tstar,fd] = oinfsetcl(A,B,E,X,U,W,K,tmax)
% OINFSETCL Calculates the maximal positively invariant set for a
%             non-autonomous discrete-time LTV system in closed-loop with
%             a controller and constraints on the control
% 
%   Usage: 
%     [Oinf,tstar,fd] = oinfsetcl(A,B,E,X,U,W,K,tmax)
%
%   Inputs:
%     A,B,E:State space A, B, and E matrices of the discrete-time system.
%     X:    State constraints in augmented form.
%     U:    Control constraints in augmented form.
%     W:    Disturbance constraints in augmented form.
%     K:    State feedback control matrix u_k = Kx_k.
%     tmax: Maximum number of iterations.
%
%   Outputs:
%     Oinf: Maximal positively invariant set for the (closed-loop) system
%             x_{k+1} = (A+BK)x_k + Ew_k contained in the input-admissible
%             subset of X, i.e. 
%             Oinf = {x_k: x_k \in X, Kx_k \in U for all k >= 0, for all w \in W}.
%     tstar: Determinedness index
%     fd:    1 if Oinf is finitely determined (tstar <= tmax).
%            0 if tstar > tmax.
%
%   See also AUG2STD, STD2AUG, ONESTEPAUT, OINFSET, OINFDIST, KINFSET
%
%
% Invariant Set Toolbox
% Version ---, Date: 10/7/2017
% Copyright (c) by Eric Kerrigan
%
% Edited by Sheila Scialanga


[D,d] = aug2std(U);
[n,m] = size(A);

if n == m
	[Oinf,tstar,fd] = oinfset(A+B*K,E,[X; D*K d],W,tmax);
else
    % find the size of A{i}, how many realisations you have
	N = length(A);
	Ac = cell(N, 1);
	for i = 1: N
    		Ac{i} = A{i} + B{i} * K;
	end
	[Oinf,tstar,fd] = oinfset(Ac,E,[X; D * K d],W,tmax);
end
